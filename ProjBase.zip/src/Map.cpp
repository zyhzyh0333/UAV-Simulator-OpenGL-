//
//  Map.cpp
//  miniProj
//
//  Created by YIHUA ZHOU on 10/24/21.
//

#include <stdio.h>
#include <algorithm>    // std::max
#include <string>
#include <vector>
#include "fssimplewindow.h"
#include "GraphicFont.h"
#include "DrawingUtilNG.h"
#include "cmath"
#include "Map.h"


void Map::draw_block(double cen_x, double cen_y, double cen_z, double height, double side_len, double scale) {
    double x1 = cen_x - 0.5 * side_len * scale;
    double x2 = cen_x + 0.5 * side_len * scale;
    double z1 = cen_z - 0.5 * side_len * scale;
    double z2 = cen_z + 0.5 * side_len * scale;
    double y1 = cen_y;
    double y2 = cen_y + height;
    DrawingUtilNG::drawCube(x1, y1, z1, x2, y2, z2);
    // black contour lines
    glColor3ub(0, 0, 0);
    glBegin(GL_LINES);
    
    // bottom
    glVertex3d(x1, y1, z1);
    glVertex3d(x2, y1, z1);
    
    glVertex3d(x2, y1, z1);
    glVertex3d(x2, y1, z2);
    
    glVertex3d(x2, y1, z2);
    glVertex3d(x1, y1, z2);
    
    glVertex3d(x1, y1, z2);
    glVertex3d(x1, y1, z1);
    
    // top
    glVertex3d(x1, y2, z1);
    glVertex3d(x2, y2, z1);
    
    glVertex3d(x2, y2, z1);
    glVertex3d(x2, y2, z2);
    
    glVertex3d(x2, y2, z2);
    glVertex3d(x1, y2, z2);
    
    glVertex3d(x1, y2, z2);
    glVertex3d(x1, y2, z1);
    
    // side
    glVertex3d(x1, y1, z1);
    glVertex3d(x1, y2, z1);
    
    glVertex3d(x2, y1, z1);
    glVertex3d(x2, y2, z1);
    
    glVertex3d(x2, y2, z2);
    glVertex3d(x2, y1, z2);
    
    glVertex3d(x1, y1, z2);
    glVertex3d(x1, y2, z2);
    

    
    glEnd();
    
}
