//
//  UAVmodel.cpp
//  miniProj
//
//  Created by YIHUA ZHOU on 10/24/21.
//

#include <stdio.h>
#include <algorithm>    // std::max
#include <string>
#include "fssimplewindow.h"
#include "GraphicFont.h"
#include "DrawingUtilNG.h"
#include "cmath"
#include "UAVmodel.h"

void UAVmodel::draw_airblade(double cen_x, double cen_y, double cen_z, double height, double side_len) {
    double radius = side_len/4;
    double thickness = height/10;
    
    for (float j = 0.0; j < thickness; j += 0.01) {
        float x, y, angle;
        float radianConvert = atan(1.) / 45.;
        radius = fabs(radius);

        // adapt the number of segments based on radius size
        int stepSize = 1;
        if (radius < 10)
            stepSize = 3;
        else if (radius < 200)
            stepSize = round((3. - 1.) / (10. - 200.) * (radius - 200.) + 1.);

        stepSize *= 6;  // always want stepSize to be a factor of 360

        glBegin(GL_POLYGON);
        

        for (int i = 0; i < 360; i += stepSize) {
            angle = i * radianConvert;
            x = cos(angle) * radius + cen_x;
            y = sin(angle) * radius + cen_z;
            glVertex3d(x, cen_y + j,y);
        }
        // std::cout<<"X: "<<x<<" Y: "<<y<<std::endl;
        glEnd();
    }
}

void UAVmodel::draw_body(double cen_x, double cen_y, double cen_z, double height, double side_len) {
    double half_side = side_len/4.0;
    double h1 = height/20.0;
    double h2 = height/4.0;
    DrawingUtilNG::drawCube(cen_x - half_side, cen_y - h1, cen_z - half_side, cen_x + half_side, cen_y - h2, cen_z + half_side);
    
}
