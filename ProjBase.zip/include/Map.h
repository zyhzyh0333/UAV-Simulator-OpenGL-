//
//  Map.h
//  miniProj
//
//  Created by YIHUA ZHOU on 10/24/21.
//

#ifndef Map_h
#define Map_h

class Map {
public:
    double cen_x,cen_y,cen_z;
    double scale;
    double side_len;
    double height;
    struct building{
        double cen_x,cen_y,cen_z;
    }building_t;

    
    void draw_block(double cen_x, double cen_y, double cen_z, double height, double side_len, double scale);
    
};


#endif /* Map_h */
