//
//  UAVmodel.h
//  miniProj
//
//  Created by YIHUA ZHOU on 10/24/21.
//

#ifndef UAVmodel_h
#define UAVmodel_h

class UAVmodel{
public:
    double cen_x,cen_y,cen_z;  // center of uav
    double height; // height of uav
    double side_len; // side length of UAV
    
    void draw_airblade(double cen_x, double cen_y, double cen_z, double height, double side_len);
    void draw_body(double cen_x, double cen_y, double cen_z, double height, double side_len);
    void draw_leg();
};


#endif /* UAVmodel_h */
