/**
 @author ZhouYihua
 ID: yihuazho@andrew.cmu.edu
 Date: 2021/10/28
 
 Brief: A UAV project based on 3D OpenGL
 
 1. "w""a""s""d": control the uav's direction. Just try it~
    "f""b": "f" makes uav move forward, this is automatically turned on.
            "b" backward.
 2. "↑""↓""←""→": control the orbiting camera.
    "g""n": change the distance between orbiting camera and uav.
 3. "m": change viewing mode. But not used anymore.

 4. The x-y-z axes follow the criteria given in Lec13.
 5. The uav currently cannot rotate.
 6. Most of the codes about camera are from flyThrough and Orbit in piazza
 
 */

#include <stdio.h>
#include <math.h>
#include <string>
#include <iostream>
#include "fssimplewindow.h"
#include "ysglfontdata.h"
#include "Camera3D.h"
#include "GraphicFont.h"
#include "DrawingUtilNG.h"

#include "OrbitingViewer.h"
#include "UAVmodel.h"
#include "Map.h"

/**
 Draw the grid lines on the ground
 @ param: grid_scale the length of the grid lines
 */
void draw_grid_lines(int grid_scale);
/**
 Draw the axes lines
 @ param: axis_scale the length of the axes lines
 */
void draw_axes_lines(int axis_scale);
/**
 The Info in left-upper corner, showing x-y-z, h-p degrees
 @ param: camera camera of uav
 */
void draw_position_info(ComicSansFont comicsans, Camera3D camera);
/**
 Draw the UAV model
 @ param: camera camera of uav
 @ param: myUAV belongs to class UAVmodel
 @ param: uav_scale currently not used. Can multiply it with the
            length, height of uav to scale it.
 */
void draw_uav(Camera3D camera,UAVmodel myUAV, double uav_scale);
/**
 Draw the buildings in the map
 @ param: camera camera of uav (not used)
 @ param: myMap belongs to class Map
 @ param: map_scale currently not used. Can multiply it with the
            length, height of blocks to scale them.
 */
void draw_blocks(Camera3D camera, Map myMap, double map_scale);
/**
 Not used.
 I'm trying to create a scanner, like mounting a beam to the uav,
 changing with the uav direction.
 */
void draw_scanner(Camera3D camera, double scanner_scale);

int main(void)
{
	bool terminate = false;
    // camera mode: obit-true, uav-false
    bool camera_mode = true;
	double vx, vy, vz;
	Camera3D camera_uav;
    Camera3D camera_orbit;
    OrbitingViewer orbit;
    UAVmodel myUAV;
    Map myMap;
    
	camera_uav.z = 10.0;   // starting position of uav
	camera_uav.y = 5.0;
	camera_uav.farZ = 5000.0; // view boundary
    
    // initialize obit camera focus point
    camera_orbit.x = camera_uav.x;
    camera_orbit.y = camera_uav.y;
    camera_orbit.z = camera_uav.z;
    camera_orbit.farZ = 5000.0;
    
    // scales for grid and axis length (most of them not used)
    int grid_scale = 1;
    int axis_scale = 1;
    double uav_scale = 1.0;
    double map_scale = 1.0;
    double scanner_scale = 1.0;

	FsOpenWindow(16, 16, 800, 600, 1);

	//initialize special fonts (after FsOpenWindow)
	ComicSansFont comicsans;
	comicsans.setColorHSV(0, 1, 1);

	while (!terminate)
	{
		FsPollDevice();

		int wid, hei;
		FsGetWindowSize(wid, hei);

		int key = FsInkey();
        switch (key) {
            case FSKEY_ESC:
                terminate = true;
                break;
            case FSKEY_M:
                camera_mode = !camera_mode;
                break;
		}

		// note that key state returns true if it is pressed
		// and I want to capture simultaneous presses
        
        // UAV camera operations
		if (FsGetKeyState(FSKEY_A))
			camera_uav.h += Camera3D::PI / 180.0;

		if (FsGetKeyState(FSKEY_D))
			camera_uav.h -= Camera3D::PI / 180.0;

		if (FsGetKeyState(FSKEY_W))
			camera_uav.p -= Camera3D::PI / 180.0;

		if (FsGetKeyState(FSKEY_S))
			camera_uav.p += Camera3D::PI / 180.0;
        
        // always moving
//		if (FsGetKeyState(FSKEY_F)) {
        if (true) {
			camera_uav.getForwardVector(vx, vy, vz);
			camera_uav.x += vx * 0.5;
			camera_uav.y += vy * 0.5;
			camera_uav.z += vz * 0.5;
            camera_orbit.x = camera_uav.x;
            camera_orbit.y = camera_uav.y;
            camera_orbit.z = camera_uav.z;
            orbit.focusX = camera_orbit.x;
            orbit.focusY = camera_orbit.y;
            orbit.focusZ = camera_orbit.z;
            
		}
		if (FsGetKeyState(FSKEY_B)) {
			camera_uav.getForwardVector(vx, vy, vz);
			camera_uav.x -= vx * 0.5;
			camera_uav.y -= vy * 0.5;
			camera_uav.z -= vz * 0.5;
            camera_orbit.x = camera_uav.x;
            camera_orbit.y = camera_uav.y;
            camera_orbit.z = camera_uav.z;
            orbit.focusX = camera_orbit.x;
            orbit.focusY = camera_orbit.y;
            orbit.focusZ = camera_orbit.z;
		}
        
        // Obit camera operations
        if (FsGetKeyState(FSKEY_LEFT)) {
            orbit.h += Camera3D::PI / 180.0;
        }
        if (FsGetKeyState(FSKEY_RIGHT))
            orbit.h -= Camera3D::PI / 180.0;

        if (FsGetKeyState(FSKEY_UP))
            orbit.p += Camera3D::PI / 180.0;

        if (FsGetKeyState(FSKEY_DOWN))
            orbit.p -= Camera3D::PI / 180.0;
        if (FsGetKeyState(FSKEY_G) && orbit.dist > 0.5) {
            orbit.dist /= 1.05;
        }
        if (FsGetKeyState(FSKEY_N) && orbit.dist < camera_orbit.farZ * .8) {
            orbit.dist *= 1.05;
        }
            
        orbit.setUpCamera(camera_orbit);
        

		glClear(GL_DEPTH_BUFFER_BIT | GL_COLOR_BUFFER_BIT);

		glViewport(0, 0, wid, hei);

		// Set up 3D drawing
        if (camera_mode) {
            camera_orbit.setUpCameraProjection();
            camera_orbit.setUpCameraTransformation();
        }else {
            camera_uav.setUpCameraProjection();
            camera_uav.setUpCameraTransformation();
            
            
        }
		

		glEnable(GL_DEPTH_TEST);
		glEnable(GL_POLYGON_OFFSET_FILL);
		glPolygonOffset(1, 1);

		// 3D drawing from here
		glColor3ub(0, 0, 255);
        draw_grid_lines(grid_scale);
		// draw axes (x is red, y is green, z is blue)
        draw_axes_lines(axis_scale);
        // draw the uav
        draw_uav(camera_uav,myUAV, uav_scale);
        // draw_scanner(camera_uav, scanner_scale);
        // draw the map
        draw_blocks(camera_uav, myMap, map_scale);

        
		glLineWidth(1);

		// Set up 2D drawing
		glMatrixMode(GL_PROJECTION);
		glLoadIdentity();
		glOrtho(0, (float)wid - 1, (float)hei - 1, 0, -1, 1);

		glMatrixMode(GL_MODELVIEW);
		glLoadIdentity();

		glDisable(GL_DEPTH_TEST);
        
        draw_position_info(comicsans,camera_uav);

		FsSwapBuffers();
		FsSleep(10);
	}

	return 0;

}


void draw_grid_lines(int grid_scale) {
    glBegin(GL_LINES);
    int x;
    int line_length = 1500 * grid_scale;
    for (x = -line_length; x <= line_length; x += line_length/25)
    {
        glVertex3i(x, 0, -line_length);
        glVertex3i(x, 0, line_length);
        glVertex3i(-line_length, 0, x);
        glVertex3i(line_length, 0, x);
    }
    glEnd();
}

void draw_axes_lines(int axis_scale) {
    glLineWidth(8);
    glBegin(GL_LINES);
    int axis_length = 1500 * axis_scale;
    
    glColor3ub(255, 0, 0);
    glVertex3i(-axis_length, 0, 0);
    glVertex3i(axis_length, 0, 0);
    
    glColor3ub(0, 255, 0);
    glVertex3i(0, -axis_length, 0);
    glVertex3i(0, axis_length, 0);
    
    glColor3ub(0, 0, 255);
    glVertex3i(0, 0, -axis_length);
    glVertex3i(0, 0, axis_length);
    
    glEnd();
}

void draw_position_info(ComicSansFont comicsans, Camera3D camera) {
    comicsans.setColorHSV(0, 1, 1);
    comicsans.drawText("Position:", 10, 60, .25);
    std::string data;
    data = "X=" + std::to_string(camera.x ) + " Y=" + std::to_string(camera.y) + " Z=" + std::to_string(camera.z);
    comicsans.setColorHSV(300, 1, .5);
    comicsans.drawText(data, 10, 80, .15);
    
    comicsans.setColorHSV(0, 1, 1);
    comicsans.drawText("Direction:", 10, 110, .25);
    double h = camera.h * 45. / atan(1.);
    double p = camera.p * 45. / atan(1.);
    data = "h=" + std::to_string((int)h % 360)
        + " deg, p=" + std::to_string((int)p % 360) + " deg";
    comicsans.setColorHSV(300, 1, .5);
    comicsans.drawText(data, 10, 130, .15);
}

void draw_uav(Camera3D camera, UAVmodel myUAV, double uav_scale) {
    double PI = 3.1415927;
    double height = 10.0;
    double side_len = 20.0;
    double s_len = side_len/4.0;
    double x_shift = 15;
    glColor3ub(0, 0, 0);
    
    // draw four airblades and one body
    myUAV.draw_airblade(camera.x-s_len-x_shift, camera.y, camera.z-s_len, height, side_len);
    myUAV.draw_airblade(camera.x-s_len-x_shift, camera.y, camera.z+s_len, height, side_len);
    myUAV.draw_airblade(camera.x+s_len-x_shift, camera.y, camera.z-s_len, height, side_len);
    myUAV.draw_airblade(camera.x+s_len-x_shift, camera.y, camera.z+s_len, height, side_len);
    glColor3ub(127, 127, 127);
    myUAV.draw_body(camera.x-x_shift, camera.y, camera.z, height, side_len);
    
}

void draw_blocks(Camera3D camera, Map myMap, double map_scale) {
    
    // draw four white blocks with black contour
    glColor3ub(255, 255, 255);
    myMap.draw_block(200, 0, 200, 300, 100, map_scale);
    glColor3ub(255, 255, 255);
    myMap.draw_block(-100, 0, 200, 100, 100, map_scale);
    glColor3ub(255, 255, 255);
    myMap.draw_block(100, 0, -100, 200, 100, map_scale);
    glColor3ub(255, 255, 255);
    myMap.draw_block(-200, 0, -100, 200, 100, map_scale);
}

// not used
void draw_scanner(Camera3D camera, double scanner_scale) {
    double rad = 30;
    double deg2red = 3.1415926/180.0;
    double x1 = camera.x-15; // make scanner middle
    double y1 = camera.y;
    double z1 = camera.z-20;
    double x2 = x1 - rad*sin(camera.h);
    double y2 = y1 + rad*sin(camera.p);
    double z2 = z1 + rad*cos(camera.h);
    
    // DrawingUtilNG::drawCube(x1, y1, z1, x2, y2, z2);
    glColor3ub(255, 0, 255);
    glLineWidth(8);
    glBegin(GL_LINES);
    glVertex3d(x1, y1, z1);
    glVertex3d(x2, y2, z2);
    glEnd();
    
}


